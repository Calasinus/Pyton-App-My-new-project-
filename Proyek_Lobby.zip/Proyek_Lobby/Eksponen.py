def Eksponen():
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    from Log import Lobby
    from PangkatEks import PangkatEks
    from AkarEks import AkarEks
    print(h3)
    print(h2),print(h1+"Eksponen Dan AntiEksponen "),print(h2)
    print(h2),print(h1+"Eksponen :"),print(h1+"Pangkat")
    print(h2),print(h1+"AntiEksponen :"),print(f"{h1}Akar\n{h1}Logaridma")
    print(h2)
    while True:
        pilihan1 = input(h1+"Pilih [Pa/Ak/Log]_ : ")
        print(h2),print(h3),print(bar)
        try:
            if pilihan1 == "Pa_":
                print(PangkatEks())
                exit()
            elif pilihan1 == "Log_":
                print(Lobby())
                exit()
                
            elif pilihan1 == "Ak_":
                print(AkarEks())
                exit()
            else:
                print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
        except ValueError:
             print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")