def faktorial(n):
        hasil = 1
    
        for i in range(1,n+1):
            hasil = hasil * i
            
        return hasil
def main():
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    print(f"{bar}\n{h3}\n{h2}")
    n = input(f"{h1}Angka/Nilai Yang \n{h2}Ingin Di Faktorialkan : \n{h2}\n{h1}")
    try:
        if int(n) == int(n):
            n = int(n)
            hasil = faktorial(n)
            print(f"{h2}\n{h1}Hasil Dari {n}! adalah :\n{h2}\n{h1}{hasil}".format(n,hasil))
            print(f"{h2}\n{h3}\n{bar}")
            exit()
            
        else:
            print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
                
    except ValueError:
            print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")