from asetpython import Struk

def kasir_digital(Version):
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    milih = ["Membeli ","Harga : ","Uang : ","Kembalian : "]
    Teh = ["Teh Sosro","Teh Ucuk"]
    H1teh = [" 4k"," 3.5k"]
    H2teh = ["4000","3500"]
    Snacker = ["Ciki Sus","Kripik Lite Small","Kripik Lite Big"]
    H1Sn = ["1500","2000","5000"]
    Dolanan = ["Hokwil","Ono","Remi"]
    H1Dolan = ["50000","85000","15000"]
    
    
    print(bar)
    print("       selamat datang")
    print("      di kasir digital")
    print(bar)
    print(f"      "+Version+"[pra-alpha]")
    print(bar)
    print(h3)
    print(h1 + "Menu :")
    print(h2)
    print(h1+"Minuman")
    print(h2)
    print(h1+"Snack")
    print(h2)
    print(h1+"Mainan")
    print(h2)
    print(h1+'Ketikan saja "[Mi/Sn/Ma]_"')
    print(h2)
    pilihan = input(h1+'Ketik : ')
    print(h2)
    print(h3)
    print(bar)
    
    while True:
        if pilihan == "Mi_" :
            print(h3)
            print(h2)
            print(h1+"Menu Minuman :")
            print(h2)
            print(h1+Teh[0])
            print(h1+"Harga 4k")
            print(h2)
            print(h1+Teh[1])
            print(h1+"Harga 3.5k")
            print(h2)
            print(h1+"[barang sedang kosong]")
            print(h2)
            print(h1+'Ketik "[So/Uc]_"')
            pilihan2 = input(h1+"Ketik : ")
            print(h2)
            print(h3)
            print(bar)
            
            if pilihan2 == "So_" :
                print(h3)
                print(h1+milih[0]+Teh[0]+" : ")
                print(h1+milih[1]+H2teh[0])
                Uang = input(h1+milih[2])
                Kembalian = int(Uang) - int(H2teh[0])
                
                if int(Kembalian) >= 0:
                    print(h1+milih[3]+str(Kembalian))
                    print(h2)
                    print(h2)
                    print(h1+"pembelian berakhir")
                    print(h2)
                    print(h3)
                    print(bar)
                    print(Struk(Teh[0],H2teh[0],Uang,Kembalian))
                    exit()
                    
                elif int(Kembalian) < 0:
                    print(h1+"Uang Anda Kurang : " + str(Kembalian))
                    print(h2)
                    print(h1+"Sistem Oprasi Error")
                    print(h2)
                    print(h3)
                    print(bar)
                    exit()
                    
            elif pilihan2 == "Uc_" :
                print(h3)
                print(h1+milih[0]+Teh[1]+" : ")
                print(h1+milih[1]+H2teh[1])
                Uang = input(h1+milih[2])
                Kembalian = int(Uang) - int(H2teh[1])
                
                if int(Kembalian) >= 0:
                    print(h1+milih[3]+str(Kembalian))
                    print(h2)
                    print(h2)
                    print(h1+"pembelian berakhir")
                    print(h2)
                    print(h3)
                    print(bar)
                    print(Struk(Teh[1],H2teh[1],Uang,Kembalian))
                    exit()
                    
                elif int(Kembalian) < 0:
                    print(h1+"Uang Anda Kurang : " + str(Kembalian))
                    print(h2)
                    print(h1+"Sistem Oprasi Error")
                    print(h2)
                    print(h3)
                    print(bar)
                    exit()
                    
        if pilihan == "Sn_" :
            print(h3)
            print(h2)
            print(h1+"Menu Snack :")
            print(h2)
            print(h1+Snacker[0])
            print(h1+"Harga 1.5k")
            print(h2)
            print(h1+Snacker[1])
            print(h1+"Harga 2k")
            print(h2)
            print(h1+Snacker[2])
            print(h1+"Harga 5k")
            print(h2)
            print(h1+"[barang sedang kosong]")
            print(h2)
            print(h1+'Ketik "[Su/LS/LB]_"')
            pilihan2 = input(h1+"Ketik : ")
            print(h2)
            print(h3)
            print(bar)
            
            if pilihan2 == "Su_" :
                print(h3)
                print(h1+milih[0]+Snacker[0]+" : ")
                print(h1+milih[1]+H1Sn[0])
                Uang = input(h1+milih[2])
                Kembalian = int(Uang) - int(H1Sn[0])
                
                if int(Kembalian) >= 0:
                    print(h1+milih[3]+str(Kembalian))
                    print(h2)
                    print(h2)
                    print(h1+"pembelian berakhir")
                    print(h2)
                    print(h3)
                    print(bar)
                    print(Struk(Snacker[0],H1Sn[0],Uang,Kembalian))
                    exit()
                    
                elif int(Kembalian) < 0:
                    print(h1+"Uang Anda Kurang : " + str(Kembalian))
                    print(h2)
                    print(h1+"Sistem Oprasi Error")
                    print(h2)
                    print(h3)
                    print(bar)
                    exit()
                    
            if pilihan2 == "LS_" :
                print(h3)
                print(h1+milih[0]+Snacker[1]+" : ")
                print(h1+milih[1]+H1Sn[1])
                Uang = input(h1+milih[2])
                Kembalian = int(Uang) - int(H1Sn[1])
                
                if int(Kembalian) >= 0:
                    print(h1+milih[3]+str(Kembalian))
                    print(h2)
                    print(h2)
                    print(h1+"pembelian berakhir")
                    print(h2)
                    print(h3)
                    print(bar)
                    print(Struk(Snacker[1],H1Sn[1],Uang,Kembalian))
                    exit()
                    
                elif int(Kembalian) < 0:
                    print(h1+"Uang Anda Kurang : " + str(Kembalian))
                    print(h2)
                    print(h1+"Sistem Oprasi Error")
                    print(h2)
                    print(h3)
                    print(bar)
                    exit()
                    
            if pilihan2 == "LB_" :
                print(h3)
                print(h1+milih[0]+Snacker[2]+" : ")
                print(h1+milih[1]+H1Sn[2])
                Uang = input(h1+milih[2])
                Kembalian = int(Uang) - int(H1Sn[2])
                
                if int(Kembalian) >= 0:
                    print(h1+milih[3]+str(Kembalian))
                    print(h2)
                    print(h2)
                    print(h1+"pembelian berakhir")
                    print(h2)
                    print(h3)
                    print(bar)
                    print(Struk(Snacker[2],H1Sn[2],Uang,Kembalian))
                    exit()
                    
                elif int(Kembalian) < 0:
                    print(h1+"Uang Anda Kurang : " + str(Kembalian))
                    print(h2)
                    print(h1+"Sistem Oprasi Error")
                    print(h2)
                    print(h3)
                    print(bar)
                    exit()
                    
                    
                    
        if pilihan == "Ma_" :
            print(h3)
            print(h2)
            print(h1+"List Mainan :")
            print(h2)
            print(h1+Dolanan[0])
            print(h1+"Harga 50k")
            print(h2)
            print(h1+Dolanan[1])
            print(h1+"Harga 85k")
            print(h2)
            print(h1+Dolanan[2])
            print(h1+"Harga 15k")
            print(h2)
            print(h1+"[barang sedang kosong]")
            print(h2)
            print(h1+'Ketik "[Ho/On/Re]_"')
            pilihan2 = input(h1+"Ketik : ")
            print(h2)
            print(h3)
            print(bar)
            
            if pilihan2 == "Ho_" :
                print(h3)
                print(h1+milih[0]+Dolanan[0]+" : ")
                print(h1+milih[1]+H1Dolan[0])
                Uang = input(h1+milih[2])
                Kembalian = int(Uang) - int(H1Dolan[0])
                
                if int(Kembalian) >= 0:
                    print(h1+milih[3]+str(Kembalian))
                    print(h2)
                    print(h2)
                    print(h1+"pembelian berakhir")
                    print(h2)
                    print(h3)
                    print(bar)
                    print(Struk(Dolanan[0],H1Dolan[0],Uang,Kembalian))
                    exit()
                    
                elif int(Kembalian) < 0:
                    print(h1+"Uang Anda Kurang : " + str(Kembalian))
                    print(h2)
                    print(h1+"Sistem Oprasi Error")
                    print(h2)
                    print(h3)
                    print(bar)
                    exit()
                    
            if pilihan2 == "On_" :
                print(h3)
                print(h1+milih[0]+Dolanan[1]+" : ")
                print(h1+milih[1]+H1Dolan[1])
                Uang = input(h1+milih[2])
                Kembalian = int(Uang) - int(H1Dolan[1])
                
                if int(Kembalian) >= 0:
                    print(h1+milih[3]+str(Kembalian))
                    print(h2)
                    print(h2)
                    print(h1+"pembelian berakhir")
                    print(h2)
                    print(h3)
                    print(bar)
                    print(Struk(Dolanan[1],H1Dolan[1],Uang,Kembalian))
                    exit()
                    
                elif int(Kembalian) < 0:
                    print(h1+"Uang Anda Kurang : " + str(Kembalian))
                    print(h2)
                    print(h1+"Sistem Oprasi Error")
                    print(h2)
                    print(h3)
                    print(bar)
                    exit()
                    
            if pilihan2 == "Ho_" :
                print(h3)
                print(h1+milih[0]+Dolanan[2]+" : ")
                print(h1+milih[1]+H1Dolan[2])
                Uang = input(h1+milih[2])
                Kembalian = int(Uang) - int(H1Dolan[2])
                
                if int(Kembalian) >= 0:
                    print(h1+milih[3]+str(Kembalian))
                    print(h2)
                    print(h2)
                    print(h1+"pembelian berakhir")
                    print(h2)
                    print(h3)
                    print(bar)
                    print(Struk(Dolanan[2],H1Dolan[2],Uang,Kembalian))
                    exit()
                    
                elif int(Kembalian) < 0:
                    print(h1+"Uang Anda Kurang : " + str(Kembalian))
                    print(h2)
                    print(h1+"Sistem Oprasi Error")
                    print(h2)
                    print(h3)
                    print(bar)
                    exit()               
        
        else:
            print(h3)
            print(h2)
            print(h1+"Komentar Error Tolong Ulang")
            print(h1+"/Mode Break Actived")
            print(h2)
            print(h3)
            print(bar)
            exit()