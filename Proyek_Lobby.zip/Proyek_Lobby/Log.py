import math
bar = "<===========================>"
h1 = "    |  •  | "
h2 = "    |     | "
h3 = "    |=====| "

error = f"{h3}\n{h2}\n{h1}Error Code Not Invalid\n{h2}\n{h3}\n{bar}"

def Logan2(n):
    n = float(n)
    
    hasil = math.log2(n)
    
    print(f"{h2}\n{h1}hasil dari [2]log({n}) adalah : \n{h2}\n{h1}{hasil}\n{h2}")
    print(f"{h3}\n{bar}")
    exit()
    
def LoganIn(n):
    n = float(n)
    
    hasil = math.log(n)
    
    print(f"{h2}\n{h1}hasil dari In({n}) adalah : \n{h2}\n{h1}{hasil}\n{h2}")
    print(f"{h3}\n{bar}")
    exit()
    
def Logan10(n):
    n = float(n)
    
    hasil = math.log10(n)
    
    print(f"{h2}\n{h1}hasil dari [10]log({n}) adalah : \n{h2}\n{h1}{hasil}\n{h2}")
    print(f"{h3}\n{bar}")
    exit()    
    
def hasillog2():
    print(f"{bar}\n{h3}\n{h2}")
    while True:
        n = input(f"{h1}Angka/Nilai : \n{h2}\n{h1}")
        try:
            if float(n)==float(n):
                print(Logan2(n))
            
            else:
                print(error) 
                exit() 
            
        except ValueError:
            print(error)
            exit()
    exit()
    
def hasillog10():
    print(f"{bar}\n{h3}\n{h2}")
    while True:
        n = input(f"{h1}Angka/Nilai : \n{h2}\n{h1}")
        try:
            if float(n)==float(n):
                print(LoganIn(n))
            
            else:
                print(error) 
                exit() 
            
        except ValueError:
            print(error)
            exit()
    exit()
    
def hasilIn():
    print(f"{bar}\n{h3}\n{h2}")
    while True:
        n = input(f"{h1}Angka/Nilai : \n{h2}\n{h1}")
        try:
            if float(n)==float(n):
                print(LoganIn(n))
            
            else:
                print(error) 
                exit() 
            
        except ValueError:
            print(error)
            exit()
    exit()        
    
def Lobby():
    print(f"{bar}\n{h3}\n{h2}\n{h1}Logridma Adalah Anti-Eksponen \n{h2}Yang Mencari Pangkat\n{h2}\n{h2}\n{h1}[Basis]log[Hasil] = [Pangkat]\n{h2}\n{bar}")
    print(f"{h2}\n{h1}Logridma Ada 3 : \n{h2}\n{h1}Log[2] \n{h2}\n{h1}(Mencari Pangkat \n{h2}Dengan Basis '2')\n{h2}")
    print(f"{h1}Log[10] \n{h2}\n{h1}(Mencari Pangkat \n{h2}Dengan Basis '10')\n{h2}\n{h1}Log[e] / In \n{h2}\n{h1}(Mencari Pangkat \n{h2}Dengan Basis e / natural)")
    Pilihan = input(f"{h2}\n{h1}Ketik [Log'2'/'10'/In]_ : ")
    print(f"{h2}\n{h3}\n{bar}")
    if Pilihan == "Log2_":
        print(hasillog2())
        exit()
        
    elif Pilihan == "Log10_":
        print(hasillog10())
        exit()
        
    elif Pilihan == "In_":
        print(hasilIn())
        exit()
    else:
        print(error)
        exit()