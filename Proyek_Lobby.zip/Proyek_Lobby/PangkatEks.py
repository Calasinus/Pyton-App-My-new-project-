def PangkatEks():
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    print(h3),print(h2)
    print(h1+"Pangkat Dan Angkanya :"),print(h2)
    while True:
        try:
            pilihan3 = input(h1+"AngkaNya : ")
            if float(pilihan3) == float(pilihan3):
                    
                print(h2)
                pilihan4 = input(h1+"Pangkatnya : ")
                if float(pilihan4)==float(pilihan4):
                    
                    hasil1 = float(pilihan3) ** float(pilihan4)
                    print(h2),print(h1+"HasilNya : "+str(hasil1))
                    print(h2),print(h3),print(bar)
                    exit()
                        
                else:
                    print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
            else:
                print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
        except ValueError:
            print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")        