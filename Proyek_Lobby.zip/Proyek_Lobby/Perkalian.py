def Perkalian():
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    print(h3)
    print(h2),print(h1+"Perkalian Hanya 2 Angka :"),print(h2)
    while True:
        try:
            pilihan1 = input(h1+"Angka Pertama : ")
            if float(pilihan1) == float(pilihan1) :
                print(h2)
                pilihan2 = input(h1+"Angka Kedua : ")
                if float(pilihan2) == float(pilihan2) :
                    print(h2)
                    hasil1 = float(pilihan1) * float(pilihan2) 
                    print(h1+"Hasil : "+str(hasil1))
                    print(h2),print(h3),print(bar)
                    exit()
                    
                else:
                    print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
            else:
                print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
        except ValueError:
            print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")