def Summer(n):
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    n = int(n)
    Sum = (n*(n+1))//2
    
    print(f"{h2}\n{h1}Hasil Dari Perjumlahan \n{h2}Berulang Adalah : \n{h1}{Summer}\n{h2}\n{h3}\n{bar}")
    exit()

def Sum():
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    while True:
        try:
            Perjumlahan = input(f"{h3}\n{h2}\n{h1}Angka/Nilai n : ")
            if int(Perjumlahan) == int(Perjumlahan):
                print(Summer(Perjumlahan))
                exit()
            else:
                print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
        except ValueError:
            print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
           