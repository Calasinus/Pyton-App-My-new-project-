
def Tebak_Angka(versi):
    import random
    bar= "<=============================>"
    h1="    |  •  | "
    h2="    |     | "
    h3="    |=====| "
    print(bar),print(f"  Selamat Datang Di Permainan \n          Tebak Angka"),print(bar)
    print(f"            {versi}"),print(f"{bar}\n           Calasinus\n{bar}"),print(h3),print(h2)
    print(h1+f"Aku Berfikir Angka\n{h2}Bermula 1 Hingga 100\n{h2}")
    
    number_to_guess = random.randint(1, 100)
    attempts = 0

    while True:
        try:
            guess = int(input(h1+"Pilih Angka : "))
            attempts += 1
            
            if guess == "Cala_":
                print(h2+f"{h1}Error Code : {number_to_guess}")
            
            if guess < number_to_guess:
                print(h2),print(f"{h1}Sangat Rendah. Coba Lagi!")
            elif guess > number_to_guess:
                print(f"{h2}\n{h1}Sangat Tinggi. Coba Lagi")
                
            else:
                print(f"{h2}\n{h1}Selamat! Kamu Telah \n{h2}Mencoba Sebanyak {attempts} Kali\n{h2}\n{h3}\n{bar}")
                exit()
        except ValueError:
            print(f"{h2}\n{h1}Tolong Memilih Angka Yang Benar!\n{h2}\n{h3}\n{bar}")