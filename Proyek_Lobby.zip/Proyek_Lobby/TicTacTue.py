def print_board(board):
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    
    """Prints the current state of the Tic-Tac-Toe board."""
    print(f"{h1}-------------")
    for row in board:
        print(f"{h2}|", end="")
        for cell in row:
            print(f" {cell} |", end="")
        print(f"\n{h2}-------------")

def get_player_move(player, board):
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    """Gets the player's move."""
    while True:
        try:
            row, col = map(int, input(f"{h1}Pemain {player}, Pilih Jalan Kamu (Baris, Kolom) : \n{h1}").split(","))
            if 1 <= row <= 3 and 1 <= col <= 3 and board[row - 1][col - 1] == " ":
                return row - 1, col - 1
            else:
                print(f"{h2}\n{h1}Jalan Invalid. Tolong Pilih Yang Benar : \n{h2}")
        except ValueError:
            print(f"{h2}\n{h1}Jalan Invalid. Tolong Pilih\n{h2}Dua Angka Dengan Koma : \n{h2}")

def check_win(board):
    """Checks if there is a winner."""
    # Check rows
    for row in board:
        if row[0] == row[1] == row[2] and row[0] != " ":
            return row[0]
    # Check columns
    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] and board[0][col] != " ":
            return board[0][col]
    # Check diagonals
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != " ":
        return board[0][0]
    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != " ":
        return board[0][2]
    # No winner
    return None

def check_draw(board):
    """Checks if the game is a draw."""
    for row in board:
        for cell in row:
            if cell == " ":
                return False
    return True
    
def Main_(versi):
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    print(f"{bar}\n       Selamat Datang\n{bar}\n       Di Tic Tac Tue \n{bar}\n          Calasinus")
    print(f"{bar}\n      v- {versi}[Pra-Rilis]\n{bar}\n{h3}\n{h2}")

 
    board = [[" " for _ in range(3)] for _ in range(3)]

    # Start the game
    current_player = "X" 

    while True:
        print_board(board)
        row, col = get_player_move(current_player, board)  # Pass board to get_player_move
        board[row][col] = current_player

        winner = check_win(board)
        if winner:
            print_board(board)
            print(f"{h1}Pemain {winner} Menang!\n{h2}\n{h3}\n{bar}")
            exit()
            
        if check_draw(board):
            print_board(board)
            print(f"{h1}Ini, Sayangnya Seri!\n{h2}\n{h3}\n{bar}")
            exit()

        # Switch players
        current_player = "0" if current_player == "X" else "X"
        