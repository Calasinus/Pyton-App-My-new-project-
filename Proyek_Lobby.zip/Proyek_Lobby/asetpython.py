def Struk(barang,harga,uang,kembalian):
    bar= "<================================>"
    h1="    |•| "
    h2="    | | " 
    h3="    |=| "
    
    print(bar),print(h3)
    print(f"{h2}Pembelian berasil\n{h3}\n{bar}"),print(h3),print(h2)
    print(f"{h1}Membeli : "),print(f"{h2}{barang}"),print(h2)
    print(f"{h1}Dengan Harga : \n{h2}{harga}"),print(h2)
    print(f"{h1}Uang Anda Sebesar : \n{h2}{uang}"),print(h2)
    print(f"{h1}Kembalian Anda Sebesar :\n{h2}{kembalian}"),print(h2)
    print(h3),print(bar),print(h3),print(f"{h1}Terimakasih Telah Membeli\n{h2}      Di Toko kami")
    print(f"{h2}\n{h3}\n{bar}")
    exit()