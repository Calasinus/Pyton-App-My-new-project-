
def kalkulator_python(version):
    bar = "<===========================>"
    h1 = "    |  •  | "
    h2 = "    |     | "
    h3 = "    |=====| "
    from Pertambahan import Pertambahan
    from Pengurangan import Pengurangan
    from Faktorial import main
    from Perkalian import Perkalian
    from Pembagian import Pembagian
    from Sum import Sum
    from Eksponen import Eksponen
    import math
    from turunan2 import Turunan
    
    print(bar),print(f"      Selamat Datang Di\n         Kalkulator \n          Clasinus \n"+bar+"\n   "+version+"[Rilis Update]")
    print(bar),print(h3),print(h2),print(h1+"Pilih Mode Perhitungan : ")
    print(h2),print(h1+"Perjumlahan"),print(h2),print(h1+"Pengurangan"),print(h2)
    print(h1+"Perkalian"),print(h2)
    print(f"{h1}Pemfaktorial / x!\n{h2}")
    print(f"{h1}Ekponen Dan Anti Ekponen\n{h2}")
    print(f"{h1}Pertambahan Berulang\n{h2}Dari 1 Hingga n Atau Sum\n{h2}")
    print(f'{h1}Turunan atau sebuah Fungsi adalah suatu\n{h2}perhitungan yang menghitung sebuah\n{h2}garis gradian dari suatu\n{h2}Fungsi atau "f(x)"')
    while True:
        try:
            pilihan = input(f"{h2}\n{h1}Pilih [+/-/×/÷/!/\n{h2}Eks/Sum/Turunan]_ : ")
            print(h2),print(h3),print(bar)
        
            if pilihan == "!_":
                print(main())
                exit()
        
            if pilihan == "+_" :
                print(Pertambahan())
                exit()
                        
            if pilihan == "-_" :
                print(Pengurangan())
                exit()
            
            if pilihan == "×_" :
                print(Perkalian())
                exit()
                
            if pilihan == "÷_" :
                print(Pembagian())
                exit()
                
            if pilihan == "Sum_":
                print(Sum())
                exit()
            
            if pilihan == "Eks_" :
                print(Eksponen())
                exit()
                
            if pilihan == "Turunan_":
                print(Turunan())
                exit()
                
            else:
                print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")    
                
        except ValueError:
            print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")        