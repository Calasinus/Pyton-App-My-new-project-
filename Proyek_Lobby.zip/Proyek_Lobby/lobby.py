
from KASIR import kasir_digital
from kalkulatorLite import kalkulator_python
from TEBAKANGKA import Tebak_Angka
from TicTacTue import Main_
import time
bar= ">==============================<"
h1="    |  •  | "
h2="    |     | "
h3="    |=====| "
App=["Kasir[1.4.5 Pra-Alpha]","Kalulator[1.9 Rilis]","Tebak.Angka[1.2 Pra-Rilis]","Tic Tac Tue[1.0 Pra-Rilis]"]
komentar=[f"App Simulasi Membeli \n{h2}Sesuatu Di Sebuah Toko \n{h2}Klontong"]
komentar1=[f"App Yang Membantu\n{h2}Perhitungan Mulai Dari \n{h2}Perjumlahan,Pengurangan\n{h2}Dan Sejenisnya \n{h2}Serta Mempunyai Sifat\n{h2}Eksponen Dan AntiEksponen"]
komentar2 = [f"App Tantangan\n{h2}Tebak Angka Bermulai\n{h2}Dari Angka 1 Hingga 100"]
komentar3 = f"App Mulipemain Yaitu \n{h2}TikTacTue. Bisa Saja Bermain Bersama-sama \n{h2}Dengan Teman Atau Kekasihmu"
App_Pilih=f"[Kasir/Kalkulator/\n{h2}Tebak.Angka/3T.]"
print(bar)
print(f"      Selamat datang di lobby\n           Mr.Calasinus")
print(bar),print("        v- 1.8.8 [Beta]")
print(bar),print("            Calasinus")
print(bar),print(h3),print(h2)
t = time.localtime(time.time())
localtime = time.asctime(t)
str = time.asctime(t)

print(h1+f"Waktu : \n{h2}"+str)
print(h2),print(h3),print(h2),print(h1+App[0])
print(h2),print(h1+komentar[0]),print(h2),print(h3)
print(h2),print(h1+App[1]),print(h2),print(h1+komentar1[0])
print(h2),print(h3),print(h2),print(h1+App[2])
print(h2),print(h1+komentar2[0]),print(h2+f"\n{h3}\n{h2}\n{h1}{App[3]}\n{h2}\n{h1}{komentar3}\n{h2}"),print(h3),print(h2)
while True:
        
    try:
        pilihan = input(h1+f"Ketik "+App_Pilih+"_ : ")
        print(h2)
        
        if pilihan == "Kasir_":
            print(h3)
            print(bar)
            print(kasir_digital("v- 1.4"))
            exit()
        
        elif pilihan == "Kalkulator_":
            print(h3)
            print(bar)
            print(kalkulator_python("v- 1.9"))
            exit()
        
        elif pilihan == "Tebak.Angka_":
            print(h3)
            print(bar)
            print(Tebak_Angka("v- 1.3"))
            exit()
            
        elif pilihan == "3T._":
            print(f"{h3}\n{bar}\n"+Main_("1.0")),exit()
            
        else :
            print(f"{h2}\n{h1}Tolong Memilih Benar!\n{h2}")
        
    except ValueError:
        print(f"{h2}\n{h1}Tolong Memilih Benar!\n{h2}")