from sympy import symbols, diff, integrate, simplify
import math

bar = "<===========================>"
h1 = "    |  •  | "
h2 = "    |     | "
h3 = "    |=====| "

def kalkulus_simbolik():
    print(f'{bar}\n{h3}\n{h2}\n{h1}Masukan Ekspesi \n{h2}Matematika (Contoh: x**2 + 3*x) \n{h2}\n{h1}Tanda pangkat adalah "**"\n{h1}Tanda kali adalah "*"\n{h1}Tanda bagi adalah "/"\n{h1}Dan sisa nya masih sama seperti\n{h2}tanda plus: "+",minus "-"\n{h2}jika akar itu adalah \n{h2}pangkat tapi dibagi 1\n{h2}akar pangka 2 adalah pangkat 1/2\n{h2}akar pangkat "n" adalag pangkat "1/n"\n{h2}')
    while True:
        # Definisikan variabel simbolik
        x = symbols('x')
        # Input ekspresi dari pengguna
        try:
            ekspresi = input(f"{h2}\n{h1}Ketikan : ")
        except ValueError:
            print(f"{h2}\n{h1}Memilih Lah Yang Benar!\n{h2}")
                # Ubah string menjadi objek matematika
        expr = simplify(ekspresi)
        print(f'{h3}\n{h2}\n{h1}dx Atau Turunan Adalah yang memperhitung garis gradian\n{h2}rumus sederhana adalah "x^(n) = (n)x^(n-1)"\n{h2}\n{h1}integral mempunyai dua tipe, pertama adalah \n{h2}anti turunan tak tentu, dan kedua adalah \n{h2}anti turunan tentu(berbatas a hingga b)\n{h2}\n{h1}integral tak tentu adalah integral yang tak memiliki \n{h2}batas maksimum, integral adalah \n{h2}kata lain dari anti turunan. \n{h2}Rumus sederhananya adalah "x^(n)" = "x^(n+1) /(n+1)"\n{h2}\n{h1}integral tentu adalah yang memiliki \n{h2}batas maksimum dari "a" hingga "b", sama seperti \n{h2}anti turunan hanya tetapi semuanya \n{h2}digantika sebuah bilangan\n{h2}')
        
        
        
        
        # Pilih operasi
        operasi = input(f"{h2}\n{h1}Pilih operasi [turunan/integral_tt/integral_t] : \n{h2}\n{h1}")
        if operasi == 'turunan' :
            hasil = diff(expr, x)
        elif operasi == 'integral_tt' :
            hasil = integrate(expr, x)
            hasil = hasil + symbols('C')  # Tambahkan konstanta C
        elif operasi == 'integral_t' :
            batas_bawah = float(input(f"{h2}\n{h1}Batas Dasar : \n{h2}\n{h1}"))
            batas_atas = float(input(f"{h2}\n{h1}Hingga Batas : \n{h2}\n{h1}"))
            hasil = integrate(expr, (x, batas_bawah, batas_atas))
        else:
            print(f"{h2}\n{h1}Operasi tidak valid. Memilih Lah yang benar!\n{h2}")
        # Format output
        hasil_str = str(simplify(hasil)).replace("**", "^").replace("*", "").replace("/", " /")
        print(f"{h2}\n{h1}Hasil:", hasil_str)
        print(f"{h2}\n{h3}\n{bar}")
        exit()

kalkulus_simbolik()
