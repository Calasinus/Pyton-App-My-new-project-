def Turunan():
				from turunan import kalkulus_simbolik
				print(kalkulus_simbolik())